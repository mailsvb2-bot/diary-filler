import os
import re
import sys
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

try:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt
except ImportError:
    Document = None
    WD_ALIGN_PARAGRAPH = None
    Pt = None


APP_TITLE = "Заполнитель дневников — Quantum Blue"
MIN_STATUS_LEN = 25
STATUS_FONT_SIZE_PT = 8
SIGNATURE_MARKER = "лечащий врач"
DATE_PREFIX_RE = re.compile(
    r"^\s*(?:"
    r"\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\s*(?:г\.?|год)?"
    r"|\d{1,2}\s+[а-яё]+\s+\d{2,4}\s*(?:г\.?|год)?"
    r")\s*",
    re.IGNORECASE,
)
WHITESPACE_RE = re.compile(r"[ \t\r\f\v]+")
MONTH_YEAR_RE = re.compile(r"^\s*(\d{1,2})\s*[./-]\s*(\d{4})\s*$")

FINAL_DIARY_TEXT = (
    "Состояние улучшилось. Жалоб не предъявляет. Острой психотической симптоматики не продуцирует. "
    "Фон настроения ровный, суицидальных мыслей не высказывает. Критика к состоянию присутствует. "
    "На текущую дату оформлена выписка из стационара. Даны рекомендации"
)

# Neon blue/cyan palette inspired by the chosen mockup.
BG = "#020817"
BG_2 = "#031633"
CARD = "#061a35"
CARD_2 = "#092d60"
BORDER = "#1ea0ff"
BORDER_SOFT = "#0b5ca8"
TEXT = "#f7fbff"
MUTED = "#a6cfff"
ACCENT = "#11c6ff"
ACCENT_2 = "#7af3ff"
ACCENT_DARK = "#0877d7"
SUCCESS = "#00ff99"
WARNING = "#ffb84d"
ERROR = "#ff5b7a"


@dataclass
class FillResult:
    filled_rows: int
    detected_rows: int
    month_cells_filled: int
    final_rows_filled: int
    next_status_index: int


def normalize_text(text: str) -> str:
    text = (text or "").replace("\xa0", " ").replace("\n", " ")
    text = WHITESPACE_RE.sub(" ", text).strip()
    return text


def clean_status_text(text: str) -> str:
    text = normalize_text(text)
    text = DATE_PREFIX_RE.sub("", text).strip(" —-–\t")
    return normalize_text(text)


def looks_like_status(text: str) -> bool:
    text = clean_status_text(text)
    low = text.lower()
    if len(text) < MIN_STATUS_LEN:
        return False
    if SIGNATURE_MARKER in low:
        return False
    if low in {"дневник наблюдения", "день госпитализации", "число", "дата", "месяц/год", "месяц / год"}:
        return False
    if re.fullmatch(r"[\d\s./-]+", text):
        return False
    return True


def extract_statuses_from_docx(path: str) -> list[str]:
    doc = Document(path)
    statuses: list[str] = []

    def add_candidate(text: str) -> None:
        cleaned = clean_status_text(text)
        if looks_like_status(cleaned):
            statuses.append(cleaned)

    for paragraph in doc.paragraphs:
        add_candidate(paragraph.text)

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    add_candidate(paragraph.text)

    return statuses


def parse_month_year(text: str) -> tuple[int, int]:
    match = MONTH_YEAR_RE.fullmatch(normalize_text(text))
    if not match:
        raise ValueError("Введите начальный месяц и год в формате ММ.ГГГГ, например 06.2026")
    month = int(match.group(1))
    year = int(match.group(2))
    if month < 1 or month > 12:
        raise ValueError("Месяц должен быть от 01 до 12")
    if year < 1900 or year > 2200:
        raise ValueError("Год выглядит некорректно")
    return month, year


def add_month(month: int, year: int, delta: int = 1) -> tuple[int, int]:
    month += delta
    while month > 12:
        month -= 12
        year += 1
    while month < 1:
        month += 12
        year -= 1
    return month, year


def format_month_year(month: int, year: int) -> str:
    return f"{month:02d}.{year:04d}"


def detect_first_month_year_from_docx(path: str) -> tuple[int, int] | None:
    try:
        doc = Document(path)
        for table in doc.tables:
            month_year_col = find_month_year_column(table)
            day_col = find_day_column(table)
            if month_year_col is None:
                continue
            for row in table.rows:
                if not is_data_row(row, day_col):
                    continue
                if len(row.cells) <= month_year_col:
                    continue
                value = normalize_text(row.cells[month_year_col].text)
                try:
                    return parse_month_year(value)
                except ValueError:
                    continue
    except Exception:
        return None
    return None


def cell_int(text: str) -> int | None:
    text = normalize_text(text)
    if not text:
        return None
    match = re.fullmatch(r"0*(\d{1,2})", text)
    if not match:
        return None
    value = int(match.group(1))
    if 1 <= value <= 31:
        return value
    return None


def is_data_row(row, day_col: int | None = None) -> bool:
    if not row.cells:
        return False
    if day_col is not None and len(row.cells) > day_col:
        return cell_int(row.cells[day_col].text) is not None
    first = normalize_text(row.cells[0].text)
    return bool(re.fullmatch(r"\d+", first))


def find_column_by_header(table, keywords: tuple[str, ...], *, fallback: int | None = None) -> int | None:
    if not table.rows:
        return fallback
    max_header_rows = min(5, len(table.rows))
    for row in table.rows[:max_header_rows]:
        for index, cell in enumerate(row.cells):
            text = normalize_text(cell.text).lower().replace(" ", "")
            if all(keyword.replace(" ", "") in text for keyword in keywords):
                return index
    return fallback


def find_diary_column(table) -> int | None:
    if not table.rows:
        return None
    for row in table.rows[: min(5, len(table.rows))]:
        for index, cell in enumerate(row.cells):
            text = normalize_text(cell.text).lower()
            if "дневник" in text or "наблюдения" in text:
                return index
    return len(table.rows[0].cells) - 1 if table.rows[0].cells else None


def find_day_column(table) -> int | None:
    if not table.rows or not table.rows[0].cells:
        return None
    col = find_column_by_header(table, ("число",), fallback=None)
    if col is not None:
        return col
    return 1 if len(table.rows[0].cells) >= 3 else 0


def find_month_year_column(table) -> int | None:
    if not table.rows or not table.rows[0].cells:
        return None
    for row in table.rows[: min(5, len(table.rows))]:
        for index, cell in enumerate(row.cells):
            text = normalize_text(cell.text).lower().replace(" ", "")
            if "месяц" in text and ("год" in text or "/" in text):
                return index
    return 2 if len(table.rows[0].cells) >= 4 else None


def clear_paragraph_keep_properties(paragraph) -> None:
    p = paragraph._p
    for child in list(p):
        if child.tag.endswith("}pPr"):
            continue
        p.remove(child)


def reset_cell_to_one_paragraph(cell):
    if not cell.paragraphs:
        return cell.add_paragraph()
    first = cell.paragraphs[0]
    clear_paragraph_keep_properties(first)
    for paragraph in list(cell.paragraphs[1:]):
        paragraph._element.getparent().remove(paragraph._element)
    return first


def extract_signature_texts(cell) -> list[str]:
    signatures: list[str] = []
    for paragraph in cell.paragraphs:
        text = normalize_text(paragraph.text)
        if SIGNATURE_MARKER in text.lower():
            signatures.append(text)
    result: list[str] = []
    for text in signatures:
        if text and text not in result:
            result.append(text)
    return result


def add_run_with_size(paragraph, text: str):
    run = paragraph.add_run(text)
    run.font.size = Pt(STATUS_FONT_SIZE_PT)
    return run


def fill_text_cell(cell, text: str, *, alignment=None) -> None:
    paragraph = reset_cell_to_one_paragraph(cell)
    if alignment is not None:
        paragraph.alignment = alignment
    add_run_with_size(paragraph, text)


def fill_diary_text_cell(cell, diary_text: str, keep_signature: bool = True) -> None:
    signatures = extract_signature_texts(cell) if keep_signature else []
    paragraph = reset_cell_to_one_paragraph(cell)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    add_run_with_size(paragraph, diary_text)
    if signatures:
        cell.add_paragraph("")
        for signature in signatures:
            signature_paragraph = cell.add_paragraph()
            signature_paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            add_run_with_size(signature_paragraph, signature)


def fill_diary_file(
    filepath: str,
    statuses: list[str],
    *,
    start_idx: int = 0,
    repeat_statuses: bool = True,
    keep_signature: bool = True,
    fill_months: bool = True,
    start_month: int = 1,
    start_year: int = 2026,
    force_final_diary: bool = True,
    final_diary_text: str = FINAL_DIARY_TEXT,
) -> FillResult:
    doc = Document(filepath)
    idx = start_idx
    filled_rows = 0
    detected_rows = 0
    month_cells_filled = 0
    final_rows_filled = 0

    data_entries: list[tuple[object, int, int | None, int | None]] = []
    for table in doc.tables:
        diary_col = find_diary_column(table)
        day_col = find_day_column(table)
        month_year_col = find_month_year_column(table)
        if diary_col is None:
            continue
        for row in table.rows:
            if not is_data_row(row, day_col):
                continue
            if len(row.cells) <= diary_col:
                continue
            data_entries.append((row, diary_col, day_col, month_year_col))

    last_entry_index = len(data_entries) - 1 if data_entries else None
    current_month = start_month
    current_year = start_year
    previous_day: int | None = None

    for entry_index, (row, diary_col, day_col, month_year_col) in enumerate(data_entries):
        day_value: int | None = None
        if day_col is not None and len(row.cells) > day_col:
            day_value = cell_int(row.cells[day_col].text)
        if day_value is not None and previous_day is not None and day_value < previous_day:
            current_month, current_year = add_month(current_month, current_year, 1)
        if day_value is not None:
            previous_day = day_value

        detected_rows += 1

        if fill_months and month_year_col is not None and len(row.cells) > month_year_col:
            fill_text_cell(
                row.cells[month_year_col],
                format_month_year(current_month, current_year),
                alignment=WD_ALIGN_PARAGRAPH.CENTER,
            )
            month_cells_filled += 1

        is_last_diary_row = force_final_diary and entry_index == last_entry_index
        if is_last_diary_row:
            fill_diary_text_cell(row.cells[diary_col], final_diary_text, keep_signature=keep_signature)
            filled_rows += 1
            final_rows_filled += 1
            continue

        if not statuses:
            continue
        if idx >= len(statuses):
            if repeat_statuses:
                idx = 0
            else:
                continue

        fill_diary_text_cell(row.cells[diary_col], statuses[idx], keep_signature=keep_signature)
        filled_rows += 1
        idx += 1

    doc.save(filepath)
    return FillResult(
        filled_rows=filled_rows,
        detected_rows=detected_rows,
        month_cells_filled=month_cells_filled,
        final_rows_filled=final_rows_filled,
        next_status_index=idx,
    )


def open_folder(path: str) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


# =============================
# PySide6 Quantum Blue UI
# =============================

def run_qt_app() -> int:
    try:
        from PySide6.QtCore import Qt, QTimer, QPointF
        from PySide6.QtGui import QFont, QPainter, QColor, QPen, QBrush, QPolygonF
        from PySide6.QtWidgets import (
            QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
            QLabel, QPushButton, QFileDialog, QMessageBox, QFrame, QLineEdit,
            QListWidget, QListWidgetItem, QCheckBox, QProgressBar, QSizePolicy,
            QGraphicsDropShadowEffect
        )
    except Exception as exc:
        print("Не установлен PySide6. Установите зависимости:")
        print("python -m pip install python-docx PySide6")
        print(f"Ошибка импорта: {exc}")
        return 2

    class HexBadge(QWidget):
        def __init__(self, text="0", parent=None, size=62):
            super().__init__(parent)
            self.text = str(text)
            self.setFixedSize(size, size)

        def paintEvent(self, event):
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing)
            w, h = self.width(), self.height()
            pts = QPolygonF([
                QPointF(w*0.50, 3), QPointF(w-8, h*0.25), QPointF(w-8, h*0.75),
                QPointF(w*0.50, h-3), QPointF(8, h*0.75), QPointF(8, h*0.25),
            ])
            for width, alpha in [(10, 35), (6, 85), (2, 255)]:
                p.setPen(QPen(QColor(82, 190, 255, alpha), width))
                p.setBrush(Qt.NoBrush)
                p.drawPolygon(pts)
            p.setBrush(QBrush(QColor(4, 24, 54, 235)))
            p.setPen(QPen(QColor(125, 225, 255), 2))
            p.drawPolygon(pts)
            p.setPen(QColor(222, 248, 255))
            p.setFont(QFont("Segoe UI", 18, QFont.Bold))
            p.drawText(self.rect(), Qt.AlignCenter, self.text)
            p.end()

    class CyberButton(QPushButton):
        def __init__(self, text, big=False, parent=None):
            super().__init__(text, parent)
            self.setCursor(Qt.PointingHandCursor)
            self.setMinimumHeight(96 if big else 58)
            self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self.setObjectName("launchButton" if big else "cyberButton")
            eff = QGraphicsDropShadowEffect(self)
            eff.setBlurRadius(44 if big else 28)
            eff.setOffset(0, 0)
            eff.setColor(QColor(0, 183, 255, 190 if big else 135))
            self.setGraphicsEffect(eff)

    class Section(QFrame):
        def __init__(self, number, title, parent=None):
            super().__init__(parent)
            self.setObjectName("section")
            self.setMinimumHeight(160)
            layout = QVBoxLayout(self)
            layout.setContentsMargins(26, 22, 26, 22)
            layout.setSpacing(12)
            header = QHBoxLayout()
            header.setSpacing(14)
            header.addWidget(HexBadge(number, self, size=56), 0, Qt.AlignTop)
            label = QLabel(title)
            label.setObjectName("sectionTitle")
            header.addWidget(label, 1, Qt.AlignVCenter)
            layout.addLayout(header)
            self.content = QVBoxLayout()
            self.content.setSpacing(10)
            layout.addLayout(self.content, 1)

    class QuantumDiaryFiller(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle(APP_TITLE)
            self.resize(1280, 820)
            self.setMinimumSize(1160, 760)
            self.statuses = []
            self.status_files = []
            self.diary_files = []
            self._setup_ui()
            self._apply_style()

        def _setup_ui(self):
            root = QWidget()
            root.setObjectName("root")
            self.setCentralWidget(root)
            main = QVBoxLayout(root)
            main.setContentsMargins(18, 18, 18, 18)
            main.setSpacing(14)

            header = QFrame()
            header.setObjectName("hero")
            header_layout = QHBoxLayout(header)
            header_layout.setContentsMargins(34, 24, 34, 24)
            header_layout.setSpacing(26)
            logo = QLabel("✎")
            logo.setObjectName("logo")
            logo.setFixedSize(104, 104)
            logo.setAlignment(Qt.AlignCenter)
            header_layout.addWidget(logo)
            title_box = QVBoxLayout()
            title = QLabel("Заполнитель дневников")
            title.setObjectName("heroTitle")
            subtitle = QLabel("Автоматическое заполнение таблиц .docx по статусам")
            subtitle.setObjectName("heroSubtitle")
            title_box.addStretch(1)
            title_box.addWidget(title)
            title_box.addWidget(subtitle)
            title_box.addStretch(1)
            header_layout.addLayout(title_box, 1)
            system = QLabel("SYSTEM READY\n● ONLINE")
            system.setObjectName("systemReady")
            system.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            header_layout.addWidget(system)
            main.addWidget(header)

            grid = QGridLayout()
            grid.setHorizontalSpacing(16)
            grid.setVerticalSpacing(16)
            grid.setColumnStretch(0, 1)
            grid.setColumnStretch(1, 1)
            grid.setRowStretch(1, 1)
            main.addLayout(grid, 1)

            s0 = Section("0", "Начальный месяц/год")
            self.month_entry = QLineEdit(datetime.now().strftime("%m.%Y"))
            self.month_entry.setObjectName("monthEntry")
            self.month_entry.setAlignment(Qt.AlignCenter)
            self.month_entry.setPlaceholderText("06.2026")
            self.fill_months_cb = QCheckBox("Заполнять 3-й столбец Месяц/Год")
            self.fill_months_cb.setChecked(True)
            hint = QLabel("Формат: 06.2026. Когда число месяца сбрасывается — месяц увеличивается автоматически.")
            hint.setObjectName("hint")
            s0.content.addWidget(self.month_entry)
            s0.content.addWidget(self.fill_months_cb)
            s0.content.addWidget(hint)
            grid.addWidget(s0, 0, 0)

            s1 = Section("1", "Выбрать файл со статусами")
            self.status_button = CyberButton("▣  Выбрать файл")
            self.status_button.clicked.connect(self.load_statuses)
            self.status_file_label = QLabel("Файл с текстами не выбран")
            self.status_file_label.setObjectName("muted")
            self.status_count_label = QLabel("Найдено статусов: 0")
            self.status_count_label.setObjectName("muted")
            s1.content.addWidget(self.status_button)
            s1.content.addWidget(self.status_file_label)
            s1.content.addWidget(self.status_count_label)
            grid.addWidget(s1, 1, 0)

            s2 = Section("2", "Выбрать файлы дневников")
            top = QHBoxLayout()
            top.addStretch(1)
            self.diary_button = CyberButton("▣  Выбрать файлы")
            self.diary_button.setMinimumWidth(250)
            self.diary_button.clicked.connect(self.load_diaries)
            top.addWidget(self.diary_button)
            s2.content.addLayout(top)
            self.diary_hint = QLabel("Таблицы дневников не выбраны")
            self.diary_hint.setObjectName("muted")
            s2.content.addWidget(self.diary_hint)
            self.files_list = QListWidget()
            self.files_list.setObjectName("filesList")
            self.files_list.setMinimumHeight(240)
            s2.content.addWidget(self.files_list, 1)
            grid.addWidget(s2, 0, 1, 2, 1)

            s3 = Section("⚙", "Дополнительные опции")
            self.final_cb = QCheckBox("Последний дневник заменить на финальную запись")
            self.final_cb.setChecked(True)
            self.folder_cb = QCheckBox("Создавать папку с датой и временем")
            self.folder_cb.setChecked(True)
            self.repeat_cb = QCheckBox("Повторять статусы по кругу, если строк больше, чем текстов")
            self.repeat_cb.setChecked(True)
            self.signature_cb = QCheckBox("Сохранять подпись лечащего врача")
            self.signature_cb.setChecked(True)
            for cb in (self.final_cb, self.folder_cb, self.repeat_cb, self.signature_cb):
                s3.content.addWidget(cb)
            grid.addWidget(s3, 2, 1)

            launch_wrap = QFrame()
            launch_wrap.setObjectName("launchWrap")
            launch_layout = QVBoxLayout(launch_wrap)
            launch_layout.setContentsMargins(18, 18, 18, 18)
            self.launch_button = CyberButton("▶   3. НАПИСАТЬ ДНЕВНИКИ", big=True)
            self.launch_button.clicked.connect(self.run_fill)
            launch_layout.addWidget(self.launch_button)
            main.addWidget(launch_wrap)

            bottom = QHBoxLayout()
            self.ready_label = QLabel("✓  Готов к работе")
            self.ready_label.setObjectName("ready")
            self.progress = QProgressBar()
            self.progress.setObjectName("progress")
            self.progress.setRange(0, 100)
            self.progress.setValue(0)
            bottom.addWidget(self.ready_label)
            bottom.addWidget(self.progress, 1)
            main.addLayout(bottom)

        def _apply_style(self):
            qss = """
                QWidget#root {
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #010818, stop:0.55 #031b3a, stop:1 #020615);
                    color: #eef8ff;
                    font-family: Segoe UI;
                }
                QFrame#hero, QFrame#section, QFrame#launchWrap {
                    background: rgba(5, 28, 62, 220);
                    border: 1px solid #2b92ff;
                    border-radius: 22px;
                }
                QFrame#hero {
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #06214a, stop:0.48 #031632, stop:1 #042a5c);
                    border: 1px solid #58b5ff;
                }
                QLabel#logo {
                    color: #8beaff;
                    border: 3px solid #35bdff;
                    border-radius: 28px;
                    background: rgba(0, 173, 255, 38);
                    font-size: 54px;
                    font-weight: 900;
                }
                QLabel#heroTitle {
                    color: #f7fbff;
                    font-size: 42px;
                    font-weight: 800;
                    letter-spacing: 0.5px;
                }
                QLabel#heroSubtitle {
                    color: #9bcaff;
                    font-size: 17px;
                }
                QLabel#systemReady {
                    color: #66ffcf;
                    font-size: 13px;
                    font-weight: 800;
                    letter-spacing: 1px;
                }
                QLabel#sectionTitle {
                    color: #f5fbff;
                    font-size: 22px;
                    font-weight: 800;
                }
                QLabel#hint, QLabel#muted {
                    color: #9cc7f2;
                    font-size: 13px;
                }
                QLineEdit#monthEntry {
                    background: rgba(0, 13, 33, 235);
                    color: #ffffff;
                    border: 2px solid #52caff;
                    border-radius: 14px;
                    padding: 16px;
                    font-size: 26px;
                    selection-background-color: #17d9ff;
                }
                QLineEdit#monthEntry:focus {
                    border: 3px solid #8af2ff;
                    background: rgba(1, 25, 64, 245);
                }
                QPushButton#cyberButton {
                    color: #91f3ff;
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #03172f, stop:0.55 #083d7b, stop:1 #03172f);
                    border: 2px solid #31dfff;
                    border-radius: 13px;
                    padding: 12px 24px;
                    font-size: 16px;
                    font-weight: 800;
                }
                QPushButton#cyberButton:hover {
                    color: white;
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #06386e, stop:0.5 #0aa2ff, stop:1 #06386e);
                    border: 2px solid #9bf8ff;
                }
                QPushButton#launchButton {
                    color: #ffffff;
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #06306a, stop:0.28 #099cff, stop:0.50 #00d7ff, stop:0.72 #099cff, stop:1 #06306a);
                    border: 3px solid #8af2ff;
                    border-radius: 24px;
                    padding: 18px;
                    font-size: 34px;
                    font-weight: 900;
                    letter-spacing: 2px;
                }
                QPushButton#launchButton:hover {
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #0c5ec5, stop:0.35 #18c5ff, stop:0.50 #a7fbff, stop:0.65 #18c5ff, stop:1 #0c5ec5);
                    border: 3px solid white;
                }
                QListWidget#filesList {
                    background: rgba(0, 11, 28, 220);
                    border: 1px solid rgba(93, 196, 255, 170);
                    border-radius: 14px;
                    color: #eaf7ff;
                    padding: 8px;
                    font-size: 14px;
                }
                QListWidget#filesList::item {
                    padding: 10px;
                    border-bottom: 1px solid rgba(80, 170, 255, 45);
                }
                QListWidget#filesList::item:selected {
                    background: rgba(0, 185, 255, 80);
                    color: white;
                }
                QCheckBox {
                    color: #e8f7ff;
                    font-size: 14px;
                    spacing: 10px;
                }
                QCheckBox::indicator {
                    width: 22px;
                    height: 22px;
                    border-radius: 11px;
                    border: 2px solid #5bcfff;
                    background: rgba(0, 17, 38, 230);
                }
                QCheckBox::indicator:checked {
                    background: qradialgradient(cx:0.5, cy:0.5, radius:0.8, stop:0 #b8ffff, stop:0.38 #22dfff, stop:1 #0866ff);
                    border: 2px solid #c4ffff;
                }
                QLabel#ready {
                    color: #7bffce;
                    font-size: 15px;
                    font-weight: 700;
                    padding: 8px;
                }
                QProgressBar#progress {
                    background: rgba(0, 13, 33, 220);
                    border: 1px solid rgba(91, 207, 255, 130);
                    border-radius: 10px;
                    height: 17px;
                    color: transparent;
                }
                QProgressBar#progress::chunk {
                    border-radius: 9px;
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #096bff, stop:0.5 #12e8ff, stop:1 #8af2ff);
                }
                QScrollBar:vertical {
                    background: rgba(0, 12, 31, 180);
                    width: 14px;
                    border-radius: 7px;
                }
                QScrollBar::handle:vertical {
                    background: #27dfff;
                    border-radius: 7px;
                    min-height: 40px;
                }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
            """
            self.setStyleSheet(qss)
            for w in self.findChildren(QFrame):
                if w.objectName() in {"hero", "section", "launchWrap"}:
                    eff = QGraphicsDropShadowEffect(w)
                    eff.setBlurRadius(34)
                    eff.setOffset(0, 0)
                    eff.setColor(QColor(0, 157, 255, 90))
                    w.setGraphicsEffect(eff)

        def load_statuses(self):
            if Document is None:
                QMessageBox.critical(self, "Нет python-docx", "Установите: python -m pip install python-docx")
                return
            path, _ = QFileDialog.getOpenFileName(self, "Выберите файл со статусами", "", "Word files (*.docx)")
            if not path:
                return
            try:
                self.statuses = extract_statuses_from_docx(path)
                self.status_files = [path]
                self.status_file_label.setText(f"Выбран файл: {Path(path).name}")
                self.status_count_label.setText(f"Найдено статусов: {len(self.statuses)}")
                self.ready_label.setText("✓  Статусы загружены")
            except Exception as exc:
                QMessageBox.critical(self, "Ошибка", str(exc))

        def load_diaries(self):
            files, _ = QFileDialog.getOpenFileNames(self, "Выберите файлы дневников", "", "Word files (*.docx)")
            if not files:
                return
            self.diary_files = sorted(files, key=lambda p: Path(p).name.lower())
            self.files_list.clear()
            for file in self.diary_files:
                item = QListWidgetItem(f"▤  {Path(file).name}        .docx")
                item.setToolTip(file)
                self.files_list.addItem(item)
            self.diary_hint.setText(f"Выбрано файлов: {len(self.diary_files)}")
            detected = detect_first_month_year_from_docx(self.diary_files[0])
            if detected:
                self.month_entry.setText(format_month_year(*detected))
            self.ready_label.setText("✓  Дневники выбраны")

        def validate_inputs(self):
            if Document is None:
                raise RuntimeError("Не установлен python-docx. Установите: python -m pip install python-docx")
            if not self.diary_files:
                raise RuntimeError("Сначала выберите файлы дневников.")
            if not self.statuses and not self.fill_months_cb.isChecked() and not self.final_cb.isChecked():
                raise RuntimeError("Нечего заполнять: выберите статусы или включите заполнение даты/финального дневника.")
            return parse_month_year(self.month_entry.text())

        def run_fill(self):
            try:
                self.validate_inputs()
            except Exception as exc:
                QMessageBox.warning(self, "Проверьте настройки", str(exc))
                return
            self.launch_button.setEnabled(False)
            self.progress.setRange(0, 0)
            self.ready_label.setText("⟳  Заполняю документы...")
            QApplication.processEvents()
            QTimer.singleShot(80, self._run_fill_now)

        def _run_fill_now(self):
            try:
                message = self.process_files()
                self.progress.setRange(0, 100)
                self.progress.setValue(100)
                self.ready_label.setText("✓  Готово")
                QMessageBox.information(self, "Готово", message)
            except Exception as exc:
                self.progress.setRange(0, 100)
                self.progress.setValue(0)
                self.ready_label.setText("✕  Ошибка")
                QMessageBox.critical(self, "Ошибка", str(exc))
            finally:
                self.launch_button.setEnabled(True)

        def process_files(self) -> str:
            start_month, start_year = self.validate_inputs()
            first_dir = Path(self.diary_files[0]).parent
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S") if self.folder_cb.isChecked() else ""
            result_name = f"ЗАПОЛНЕННЫЕ_ДНЕВНИКИ_{stamp}" if stamp else "ЗАПОЛНЕННЫЕ_ДНЕВНИКИ"
            result_dir = first_dir / result_name
            result_dir.mkdir(parents=True, exist_ok=True)
            idx = 0
            total_rows = total_dates = total_final = ok = 0
            lines = ["ОТЧЁТ ПО ЗАПОЛНЕНИЮ ДНЕВНИКОВ", f"Дата запуска: {datetime.now():%d.%m.%Y %H:%M:%S}", f"Папка результата: {result_dir}", ""]
            for n, src in enumerate(self.diary_files, start=1):
                dst = result_dir / Path(src).name
                shutil.copy2(src, dst)
                result = fill_diary_file(
                    str(dst),
                    self.statuses,
                    start_idx=idx,
                    repeat_statuses=self.repeat_cb.isChecked(),
                    keep_signature=self.signature_cb.isChecked(),
                    fill_months=self.fill_months_cb.isChecked(),
                    start_month=start_month,
                    start_year=start_year,
                    force_final_diary=self.final_cb.isChecked(),
                )
                idx = result.next_status_index
                ok += 1
                total_rows += result.filled_rows
                total_dates += result.month_cells_filled
                total_final += result.final_rows_filled
                percent = int(n / len(self.diary_files) * 100)
                self.progress.setRange(0, 100)
                self.progress.setValue(percent)
                self.ready_label.setText(f"⟳  Обработано: {n}/{len(self.diary_files)}")
                QApplication.processEvents()
                lines.append(f"{Path(src).name}: найдено строк {result.detected_rows}, заполнено дневников {result.filled_rows}, дат {result.month_cells_filled}, финальных записей {result.final_rows_filled}")
            lines.extend(["", f"Файлов обработано: {ok}/{len(self.diary_files)}", f"Дневников заполнено: {total_rows}", f"Дат заполнено: {total_dates}", f"Финальных записей: {total_final}"])
            (result_dir / "ОТЧЁТ.txt").write_text("\n".join(lines), encoding="utf-8")
            open_folder(str(result_dir))
            return f"Готово. Обработано файлов: {ok}/{len(self.diary_files)}\n\nРезультаты сохранены в папке:\n{result_dir}"

    app = QApplication(sys.argv)
    app.setApplicationName(APP_TITLE)
    window = QuantumDiaryFiller()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(run_qt_app())
